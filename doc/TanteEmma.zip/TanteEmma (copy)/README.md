# SetUP:

``
composer install
``

``
npm install
``

``
gulp
``

### Start Server

``
php bin/console server:start
``
