'use strict';
global.jQuery = global.$ = require('jquery');
require('bootstrap');
require('admin-lte');
require('angular');
require('angular-ui-bootstrap');
require('angular-messages');
require('jquery-ui-bundle');
